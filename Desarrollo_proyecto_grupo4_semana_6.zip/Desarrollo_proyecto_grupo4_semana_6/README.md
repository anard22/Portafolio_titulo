# Smart Arena Experience - Avance Semana 6 (Sprint I completo)

Repositorio con el avance del desarrollo del sistema de acuerdo a la
planificacion de la Fase I del Proyecto APT (Semana 6):

- HU-01: Registro de usuarios con roles y validacion (Completada)
- HU-02: Inicio de sesion con control de acceso por rol (Completada)
- HU-03: Cierre de sesion seguro (Completada)

## Stack tecnologico
- **Backend:** Python 3 + Flask, session segura (cookie), validacion server-side.
- **Base de datos:** MySQL 8 (SP, triggers, integridad referencial, 3FN).
- **Frontend:** HTML5, CSS3 (responsive) y JavaScript vanilla.

## Avance vs Semana 5
- Se implemento el endpoint `/api/registro` completo con cifrado bcrypt
  y validacion de correo unico (excepcion 1062 controlada).
- Se implemento el endpoint `/api/login` con verificacion de credenciales
  y redireccion segun rol (administrador / operador / cliente).
- Se implemento el endpoint `/api/logout` que invalida la sesion.
- Se creo la interfaz de registro (`register.html`) con validacion
  de requisitos de contrasena segura (8+ caracteres, mayuscula, especial).
- Se agrego la vista de panel basico segun el rol del usuario.
- Se estandarizaron los mensajes de error al espanol.
- Se corrigio la redireccion por rol (impedimento 2 del Sprint I).
- Se mantienen los SP y triggers de la version anterior.

## Estructura
```
desarrollo/
├── README.md
├── bd/
│   └── smart_arena_db.sql
├── backend/
│   ├── app.py
│   ├── config.py
│   ├── db.py
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── login.html
    ├── register.html
    ├── css/
    │   └── estilos.css
    └── js/
        └── app.js
```

## Proximo sprint (Semana 7 - Sprint II)
- HU-04: Editar perfil de usuario.
- HU-05: Restablecer contrasena.
- HU-06: CRUD de eventos del recinto.
- HU-07: Compra de tickets de acceso.
