# -*- coding: utf-8 -*-
"""Smart Arena Experience - Backend Sprint I (Semana 6).

Endpoints completados en Sprint I:
  POST /api/registro   -> registrar usuario nuevo con bcrypt
  POST /api/login      -> autenticar y establecer sesion por rol
  GET  /api/logout     -> cerrar sesion
  GET  /api/health     -> verificacion de estado
  GET  /inicio         -> panel basico segun rol
"""
import functools
import re

import bcrypt
from flask import Flask, jsonify, redirect, request, session, url_for

from db import (
    autenticar_usuario,
    registrar_usuario,
    existe_correo,
)

app = Flask(__name__)
app.config.from_object("config.Config")


def requiere_login(rol_requerido=None):
    """Decorador que controla acceso por sesion y rol."""
    def decorador(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            if "usuario_id" not in session:
                return redirect(url_for("login"))
            if rol_requerido and session.get("rol") != rol_requerido:
                return jsonify({"error": "No tiene permisos para esta operacion."}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorador


def _validar_contrasena(pw):
    """Valida requisitos de seguridad: 8+ chars, 1 mayuscula, 1 especial."""
    if len(pw) < 8:
        return False, "La contrasena debe tener al menos 8 caracteres."
    if not re.search(r"[A-Z]", pw):
        return False, "La contrasena debe contener al menos una letra mayuscula."
    if not re.search(r"[^A-Za-z0-9]", pw):
        return False, "La contrasena debe contener al menos un caracter especial."
    return True, ""


@app.route("/")
def index():
    return jsonify({"mensaje": "Smart Arena Experience API activa.",
                    "endpoints": ["/api/registro", "/api/login", "/api/logout"]})


# ------------------------------------------------------------------ REGISTRO
@app.route("/api/registro", methods=["POST"])
def api_registro():
    """Registrar un nuevo usuario (HU-01)."""
    data = request.get_json(silent=True) or request.form
    nombre = (data.get("nombre") or "").strip()
    email = (data.get("email") or "").strip().lower()
    contrasena = data.get("contrasena") or data.get("password") or ""

    if not nombre or not email or not contrasena:
        return jsonify({"error": "Todos los campos son obligatorios (nombre, email, contrasena)."}), 400

    # Validar formato de correo
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return jsonify({"error": "El formato del correo electronico no es valido."}), 400

    # Validar contrasena segura
    ok, msg = _validar_contrasena(contrasena)
    if not ok:
        return jsonify({"error": msg}), 400

    # Verificar que el correo no este duplicado
    if existe_correo(email):
        return jsonify({"error": "El correo electronico ya esta registrado. Inicie sesion o use otro correo."}), 409

    # Cifrar contrasena con bcrypt
    hash_pw = bcrypt.hashpw(contrasena.encode("utf-8"), bcrypt.gensalt())

    try:
        usuario_id = registrar_usuario(nombre, email, hash_pw.decode("utf-8"), "cliente")
    except Exception:
        return jsonify({"error": "Error al registrar el usuario. Intentelo nuevamente."}), 500

    return jsonify({"mensaje": "Usuario registrado exitosamente.",
                    "usuario_id": usuario_id}), 201


# ------------------------------------------------------------------ LOGIN
@app.route("/api/login", methods=["POST"])
def api_login():
    """Autenticar usuario y establecer sesion (HU-02)."""
    data = request.get_json(silent=True) or request.form
    email = (data.get("email") or "").strip().lower()
    contrasena = data.get("contrasena") or data.get("password") or ""

    if not email or not contrasena:
        return jsonify({"error": "Correo y contrasena son obligatorios."}), 400

    usuario = autenticar_usuario(email)
    if not usuario:
        return jsonify({"error": "Credenciales incorrectas. Verifique su correo y contrasena."}), 401

    # Verificar contrasena con bcrypt
    try:
        if not bcrypt.checkpw(contrasena.encode("utf-8"),
                              usuario["password_hash"].encode("utf-8")):
            return jsonify({"error": "Credenciales incorrectas. Verifique su correo y contrasena."}), 401
    except Exception:
        return jsonify({"error": "Error al validar las credenciales."}), 500

    # Establecer sesion con datos del usuario
    session["usuario_id"] = usuario["id"]
    session["rol"] = usuario["rol"]
    session["nombre"] = usuario["nombre"]
    session.permanent = True  # cookie segura

    # Redirigir segun el rol del usuario
    return jsonify({"mensaje": "Bienvenido " + usuario["nombre"] + ".",
                    "rol": usuario["rol"],
                    "redirect": url_for("inicio")}), 200


# ------------------------------------------------------------------ LOGOUT
@app.route("/api/logout")
def api_logout():
    """Cerrar sesion e invalidar la cookie (HU-03)."""
    session.clear()
    return jsonify({"mensaje": "Sesion cerrada correctamente.",
                    "redirect": url_for("login")}), 200


# ------------------------------------------------------------------ INICIO
@app.route("/inicio")
@requiere_login()
def inicio():
    """Panel basico segun el rol del usuario autenticado."""
    rol = session.get("rol")
    nombre = session.get("nombre")
    return jsonify({
        "mensaje": "Hola " + str(nombre) + ", bienvenido al panel.",
        "rol": rol,
        "acciones_disponibles": {
            "administrador": ["Gestionar eventos", "Ver reportes"],
            "operador": ["Gestionar pedidos", "Ver reservas"],
            "cliente": ["Comprar tickets", "Hacer pedidos", "Ver eventos"],
        }.get(rol, []),
    })


# ------------------------------------------------------------------ HEALTH
@app.route("/api/health")
def health():
    return jsonify({"estado": "ok", "proyecto": "Smart Arena Experience",
                    "semana": 6, "sprint": "I"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)