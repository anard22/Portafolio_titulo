import mysql.connector
from config import Config


def get_connection():
    """Retorna una conexion a MySQL."""
    return mysql.connector.connect(
        host=Config.DB_HOST,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        database=Config.DB_NAME,
    )


def autenticar_usuario(email):
    """Invoca sp_autenticar_usuario. Retorna dict o None."""
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.callproc("sp_autenticar_usuario", [email])
        for res in cur.stored_results():
            rows = res.fetchall()
            return rows[0] if rows else None
        return None
    finally:
        conn.close()


def existe_correo(email):
    """Verifica si ya existe un usuario con ese correo (avance S6).

    Controla la excepcion 1062 (correo duplicado) del Sprint I,
    de modo que la API entregue un mensaje claro al usuario.
    """
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM usuario WHERE email = %s", (email,))
        return cur.fetchone()[0] > 0
    finally:
        conn.close()


def registrar_usuario(nombre, email, password_hash, rol="cliente"):
    """Invoca sp_registrar_usuario y retorna el id insertado."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.callproc("sp_registrar_usuario", [nombre, email, password_hash, rol])
        conn.commit()
        cur.execute("SELECT LAST_INSERT_ID()")
        return cur.fetchone()[0]
    finally:
        conn.close()