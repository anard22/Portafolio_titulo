/* Smart Arena Experience - frontend JS (Semana 6 - Sprint I) */
var API = "/";

/* ===================================================== Mostrar/ocultar contrasena */
document.addEventListener("DOMContentLoaded", function () {
  var toggleLogin = document.getElementById("mostrar-password-login");
  var toggleReg   = document.getElementById("mostrar-password-reg");

  if (toggleLogin) {
    toggleLogin.addEventListener("change", function () {
      var pw = document.getElementById("password-login");
      pw.type = toggleLogin.checked ? "text" : "password";
    });
  }
  if (toggleReg) {
    toggleReg.addEventListener("change", function () {
      var pw  = document.getElementById("password-reg");
      var pw2 = document.getElementById("password2-reg");
      var tipo = toggleReg.checked ? "text" : "password";
      if (pw)  pw.type  = tipo;
      if (pw2) pw2.type = tipo;
    });
  }

  /* ================================================= LOGIN */
  var formLogin = document.getElementById("form-login");
  if (formLogin) {
    formLogin.addEventListener("submit", function (e) {
      e.preventDefault();
      var msg  = document.getElementById("mensaje-login");
      var data = new FormData(formLogin);
      msg.hidden = true;

      fetch(API + "api/login", { method: "POST", body: data })
        .then(function (res) {
          return res.json().then(function (json) {
            if (res.ok && json.redirect) {
              window.location.href = json.redirect;
            } else {
              msg.hidden = false;
              msg.className = "mensaje error";
              msg.textContent = json.error || "Error al iniciar sesion.";
            }
          });
        })
        .catch(function () {
          msg.hidden = false;
          msg.className = "mensaje error";
          msg.textContent = "No se pudo conectar con el servidor.";
        });
    });
  }

  /* ================================================= REGISTRO */
  var formReg = document.getElementById("form-registro");
  if (formReg) {
    formReg.addEventListener("submit", function (e) {
      e.preventDefault();
      var msg    = document.getElementById("mensaje-reg");
      var nombre = document.getElementById("nombre-reg").value.trim();
      var email  = document.getElementById("email-reg").value.trim();
      var pw     = document.getElementById("password-reg").value;
      var pw2    = document.getElementById("password2-reg").value;
      msg.hidden = true;

      if (!nombre || !email || !pw || !pw2) {
        msg.hidden = false; msg.className = "mensaje error";
        msg.textContent = "Todos los campos son obligatorios.";
        return;
      }
      if (pw !== pw2) {
        msg.hidden = false; msg.className = "mensaje error";
        msg.textContent = "Las contrasenas no coinciden.";
        return;
      }
      if (pw.length < 8 || !/[A-Z]/.test(pw) || !/[^A-Za-z0-9]/.test(pw)) {
        msg.hidden = false; msg.className = "mensaje error";
        msg.textContent = "La contrasena debe tener 8+ caracteres, 1 mayuscula y 1 especial.";
        return;
      }

      fetch(API + "api/registro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre: nombre, email: email, contrasena: pw }),
      })
        .then(function (res) {
          return res.json().then(function (json) {
            if (res.ok) {
              msg.hidden = false; msg.className = "mensaje exito";
              msg.textContent = "Registro exitoso. Redirigiendo al inicio de sesion...";
              setTimeout(function () { window.location.href = "login.html"; }, 1800);
            } else {
              msg.hidden = false; msg.className = "mensaje error";
              msg.textContent = json.error || "Error al registrarse.";
            }
          });
        })
        .catch(function () {
          msg.hidden = false; msg.className = "mensaje error";
          msg.textContent = "No se pudo conectar con el servidor.";
        });
    });
  }

  /* ================================================= LOGOUT (en el panel) */
  var btnLogout = document.getElementById("btn-logout");
  if (btnLogout) {
    btnLogout.addEventListener("click", function () {
      fetch(API + "api/logout").then(function () {
        window.location.href = "login.html";
      }).catch(function () {
        window.location.href = "login.html";
      });
    });
  }

  cargarEventos();
});

/* ================================================= Cargar eventos (index) */
function cargarEventos() {
  var contenedor = document.getElementById("lista-eventos");
  if (!contenedor) return;

  fetch(API + "api/eventos")
    .then(function (res) { return res.json(); })
    .then(function (eventos) {
      if (!Array.isArray(eventos) || eventos.length === 0) {
        contenedor.innerHTML = "<p>No hay eventos publicados por ahora.</p>";
        return;
      }
      contenedor.innerHTML = "";
      eventos.forEach(function (ev) {
        var t = document.createElement("article");
        t.className = "tarjeta-evento";
        t.innerHTML =
          "<h3>" + escapeHtml(ev.nombre) + "</h3>" +
          "<p>" + ev.fecha + " &middot; " + ev.hora + "</p>" +
          "<p>" + escapeHtml(ev.recinto) + "</p>";
        contenedor.appendChild(t);
      });
    })
    .catch(function () {
      contenedor.innerHTML = "<p>No se pudieron cargar los eventos.</p>";
    });
}

function escapeHtml(texto) {
  var d = document.createElement("div");
  d.textContent = texto || "";
  return d.innerHTML;
}